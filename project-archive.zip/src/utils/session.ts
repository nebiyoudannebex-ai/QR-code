export const SESSION_TIMEOUT_MS = 15 * 60 * 1000;
const SESSION_STORAGE_KEY = 'session_last_activity';

export function createSessionTimeoutHandler(onExpire: () => void, useSessionStorage: boolean = false) {
  let timeoutId: number | undefined;
  let active = true;

  const storage = useSessionStorage ? sessionStorage : localStorage;

  const reset = () => {
    if (!active) return;
    if (timeoutId) {
      window.clearTimeout(timeoutId);
    }
    // Store last activity time
    storage.setItem(SESSION_STORAGE_KEY, Date.now().toString());
    timeoutId = window.setTimeout(() => {
      active = false;
      storage.removeItem(SESSION_STORAGE_KEY);
      onExpire();
    }, SESSION_TIMEOUT_MS);
  };

  const stop = () => {
    active = false;
    if (timeoutId) {
      window.clearTimeout(timeoutId);
    }
  };

  const checkSessionOnLoad = () => {
    const lastActivity = storage.getItem(SESSION_STORAGE_KEY);
    if (lastActivity) {
      const elapsed = Date.now() - parseInt(lastActivity, 10);
      if (elapsed >= SESSION_TIMEOUT_MS) {
        storage.removeItem(SESSION_STORAGE_KEY);
        onExpire();
        return false;
      }
      // Session still valid, reset timer with remaining time
      const remainingTime = SESSION_TIMEOUT_MS - elapsed;
      timeoutId = window.setTimeout(() => {
        active = false;
        storage.removeItem(SESSION_STORAGE_KEY);
        onExpire();
      }, remainingTime);
      return true;
    }
    return false;
  };

  const events: Array<keyof WindowEventMap> = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'touchmove', 'click', 'scroll', 'pointermove'];

  const attach = () => {
    const sessionValid = checkSessionOnLoad();
    if (!sessionValid) {
      reset();
    }
    events.forEach(eventName => {
      window.addEventListener(eventName, reset, { passive: true });
    });
  };

  const detach = () => {
    events.forEach(eventName => {
      window.removeEventListener(eventName, reset);
    });
    stop();
  };

  return { attach, detach, reset };
}
